import { Injectable } from '@angular/core';

import { HttpClient } from "@angular/common/http";
import { Note } from "../app/note/note";
import { Observable } from 'rxjs/Observable';

@Injectable()
export class NoteService {

  constructor(private http: HttpClient) { }

  getNotes(): Observable<Array<Note>> {
    return this.http.get<Array<Note>>('http://localhost:3000/notes');
  }

  saveNote(note: Note): Observable<Note> {
    return this.http.post<Note>('http://localhost:3000/notes', note);
  }

  deleteNote(_id): Observable<Note> {
    console.log("Inside NoteService");
    console.log(_id);
    return this.http.delete<Note>('http://localhost:3000/notes/5'+_id);
  }

}
