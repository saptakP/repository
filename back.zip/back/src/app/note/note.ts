export class Note {
    id: number;
    title: string;
    description : string;
    status : string;

    constructor() {
        this.title = '';
        this.description = '';
        this.status = '';
    }
}
