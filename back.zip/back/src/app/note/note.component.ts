import { Component, OnInit } from '@angular/core';
import { Console } from '@angular/core/src/console';
import { Note } from './note';
import { NoteService } from '../../services/note.service';
//import { Event } from '_debugger';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {
  
  note: Note = new Note();
  notes: Array<Note> = [];

  constructor(private noteService: NoteService) { }
  
  ngOnInit() {
      this.noteService.getNotes().subscribe(
      data => this.notes = data,
      err => console.log(err)
    );
  }

  saveNote() {
    this.noteService.saveNote(this.note).subscribe(
      data => this.notes.push(data),
      err => console.log(err)
    );
    this.note = new Note();
  }

  deleteNote(id) {
    let elementId: string = id;
    console.log("Inside note component.");
    console.log(elementId);
    /*this.noteService.deleteNote(event.target.id).subscribe(
      err => console.log(err)
    );*/
  }
}
